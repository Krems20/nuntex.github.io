let blinkCount = 3;
let currentCount = 0;

const blinkLogo = () => {
    const logo = document.getElementById("logo");
    logo.style.opacity = (currentCount % 2 === 0) ? "1" : "0";
    currentCount++;

    if (currentCount < blinkCount) {
        setTimeout(blinkLogo, 100);
    } else {
        window.location.href = "https://example.com";
    }
};

setTimeout(blinkLogo, 1000);